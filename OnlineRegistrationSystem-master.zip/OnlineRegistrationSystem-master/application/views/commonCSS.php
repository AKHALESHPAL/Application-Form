<?=link_tag('images/others/duet.ico', 'icon', 'image/x-ico');?>
<?=link_tag('images/others/duet.ico', 'shortcut icon', 'image/x-ico');?>
<?=link_tag('css/960.css')?>
<?=link_tag('css/reset.css')?>
<?=link_tag('css/text.css')?>
<?=link_tag('css/style.css')?>
<?=link_tag('sdmenu/sdmenu.css')?> 